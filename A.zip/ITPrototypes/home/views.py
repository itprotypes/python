﻿from django.shortcuts import render,redirect
from .forms import work_order_form as WOF
from .aditionals import WGMC
from .aditionals import WODMC
# Create your views here.
def home(request):
	return render(request,'home/home_page.html',None)
def work_order(request):
	post=request.POST#will comtain form data on post method
	if request.method=='POST':
		print(post)
		WGMC(post)
		WODMC(post)
		return redirect('work_order')
	return render(request,'home/work_order_page.html',None)