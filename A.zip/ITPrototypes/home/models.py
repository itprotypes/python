﻿from django.db import models
from django.utils import timezone
#python manage.py makemigrations
#python manage.py migrate
# Create your models here.
class work_giver(models.Model):
	email=models.CharField(max_length=150,blank=False)
	phone_number=models.CharField(max_length=18,blank=False)
	
class work_order_data(models.Model):
	email=models.CharField(max_length=150,blank=False)
	phone_number=models.CharField(max_length=18,blank=False)
	adress=models.TextField(blank=False)
	work_type=models.CharField(max_length=6,blank=False)
	budget=models.CharField(max_length=14,blank=True)
	budget_in_words=models.CharField(max_length=1400,blank=True)
	on_date_delivery=models.CharField(max_length=6,blank=True)
	date_posted=models.DateTimeField(default=timezone.now)
	details=models.TextField(blank=True,default=None)
	