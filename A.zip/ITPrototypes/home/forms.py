﻿from django import forms
#########
class work_order_form(forms.Form):
	email=forms.EmailField()