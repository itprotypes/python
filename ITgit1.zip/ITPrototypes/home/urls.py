﻿from django.urls import path,include
from . import views
urlpatterns = [
   # path('admin/', admin.site.urls),
	path('',views.home,name='home'),
	path('work_order/',views.work_order,name='work_order'),
]