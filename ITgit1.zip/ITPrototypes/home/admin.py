﻿from django.contrib import admin
from .models import work_giver as WG
from .models import work_order_data as WOD
# Register your models here.
@admin.register(WG)
class WG(admin.ModelAdmin):
    list_display = ("id","email","phone_number")
    ordering = ("-id",)

@admin.register(WOD)
class WOD(admin.ModelAdmin):
    list_display = ("id","date_posted","email","phone_number","adress","budget")
    ordering = ("-date_posted",)
