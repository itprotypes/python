﻿from .models import work_giver as WG
from .models import work_order_data as WOD
from django.core.mail import send_mail
from ITPrototypes.settings import EMAIL_HOST_USER




def WGMC(context):#WGMC stands for work giver model config
	if len(WG.objects.all().filter(email=context.get('email'),phone_number=context.get('phone')))==0:
		print('hi')
		new=WG(email=context.get('email'),phone_number=context.get('phone'))
		new.save()
		
#end function		
	
	
		
		
def WODMC(post):#WGMC stands for work order data model config
	#vars 
	email=post.get('email')
	phone_number=post.get('phone')
	adress='null'
	details=post.get('details')
	work_type=post.get('project')
	budget=post.get('budget')
	budget_in_words='null'
	on_date_delivery=post.get('deadline')
	#end var
	#database part to save work order
	new_order=WOD(email=email,phone_number=phone_number,adress=adress,work_type=work_type,budget=budget,budget_in_words=budget_in_words,on_date_delivery=on_date_delivery,details=details)
	new_order.save()
	##end data base
	#send mail to the user and the admin
	
		#->admim mail
	body=f'an work order ordered form {email} has been proposed .author phone number is {phone_number},adress -> {adress}..work budget is -->{budget}/-...,they want a {work_type} to be done .......their project details is {details}....the project deadline is {on_date_delivery}....'
	title=f'a {work_type} need to be done'
	
	send_mail('django mail',body,'prototypesit@gmail.com',['prototypesit@gmail.com'],fail_silently=False)
		#end admin mail
		#-->user
	user_body=f'work order was successfull'
#	i='hhjjjkkjggguioojvfgguuijiioohgfffffffgggggvv'
#	for j in i:
	send_mail('alert',user_body,EMAIL_HOST_USER,[email],fail_silently=False)
		#print('s8ccess')
		#print(j)
		#end usermail
	#end mail
#end function	